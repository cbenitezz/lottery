</div>
<!-- End Wrapper -->
<!-- All Jquery -->
<!--
<script src="{{-- asset('asset/js/jquery.min.js') --}}"></script>-->
<script src="{{ asset('asset/js/jquery-3.5.1.js') }}"></script>

<!-- Bootstrap tether Core JavaScript -->
<script src="{{ asset('asset/js/lib/bootstrap/js/popper.min.js') }}"></script>
<script src="{{ asset('asset/js/lib/bootstrap/js/bootstrap.min.js') }}"></script>
<!-- slimscrollbar scrollbar JavaScript -->
<script src="{{ asset('asset/js/jquery.slimscroll.js') }}"></script>
<!--Menu sidebar -->
<script src="{{ asset('asset/js/sidebarmenu.js') }}"></script>

<!--stickey kit -->
<script src="{{ asset('asset/js/lib/sticky-kit-master/dist/sticky-kit.min.js') }}"></script>



<!--Custom JavaScript -->
<script src="{{ asset('asset/js/custom.min.js') }}"></script>
@stack('script')

</body>

</html>
