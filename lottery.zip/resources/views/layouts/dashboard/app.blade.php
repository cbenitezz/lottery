
    @include('layouts.dashboard.head')
    @include('layouts.dashboard.header')

    @include('layouts.dashboard.page_wrapper')

    @include('layouts.dashboard.sidebar')
    @include('layouts.dashboard.scripts')

