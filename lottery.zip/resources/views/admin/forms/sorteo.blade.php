<div class="col-md-8" style="margin-top:20px;">
    <div class="card">
        <div class="header">
            <h4 class="title">FORMULARIO DE CREACIÓN DE RIFA </h4>
        </div>


        <div class="content">
  <form method="POST" action="https://rifa.tucasayacolombia.com/rifa/10" accept-charset="UTF-8"><input name="_method" type="hidden" value="PATCH"><input name="_token" type="hidden" value="SFDzyxVi9Jci0tkC04mh5tMlNLqfeL6NF4ko0JtL">


                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">

                            <label>ESLOGAN *</label>
                            <input class="form-control" autofocus="autofocus" readonly="readonly" name="slogan" type="text" value="Continuamos Haciendo Realidad Tu sueño de tener casa propia">
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">

                            <label>NIT *</label>
                            <input class="form-control" autofocus="autofocus" readonly="readonly" name="nit" type="text" value="00018417576">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">

                            <label>NOMBRE *</label>
                            <input class="form-control" readonly="readonly" name="nombre" type="text" value="Rifa Tu Casa !Ya¡">
                        </div>
                    </div>
                </div>


                <div class="row">
                 <div class="col-md-12">
                        <div class="form-group">
                            <label>REPRESENTANTE *</label>
                                  <input class="form-control" readonly="readonly" name="representante" type="text" value="Azael Vargas y Carlos Lopez ">
                        </div>
                    </div>

                </div>


                <div class="row">



                   <div class="col-md-6">
                        <div class="form-group">
                            <label>FECHA DE INCIO *</label>
                                  <input class="form-control" readonly="readonly" name="fecha_inicio" type="date" value="2021-12-23">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>FECHA FINAL *</label>

                              <input class="form-control" readonly="readonly" name="fecha_final" type="date" value="2022-08-06">

                        </div>
                    </div>



                </div>


                <div class="row">


                       <div class="col-md-6">
                            <div class="form-group">
                                <label>VALOR DE LA BOLETA *</label>
                             <input class="form-control" readonly="readonly" name="vlr_boleta" type="text" value="90000">
                            </div>
                    </div>



                       <div class="col-md-6">
                        <div class="form-group">
                            <label>LOTERÍA *</label>
                                  <input class="form-control" readonly="readonly" name="loteria" type="text" value="Boyaca">
                        </div>
                    </div>




                </div>

                 <div class="row">


                      <div class="col-md-4">
                        <div class="form-group">
                            <label>COMISIÓN POR VENTA *</label>
                              <input class="form-control" readonly="readonly" name="comision_venta" type="text" value="27000">
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="form-group">
                            <label>COMISIÓN POR COBRO *</label>
                                  <input class="form-control" readonly="readonly" name="comision_cobro" type="text" value="0">
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="form-group">
                            <label>COMISIÓN POR EXTRA *</label>
                                  <input class="form-control" readonly="readonly" name="comision_extra" type="text" value="27000">
                        </div>
                    </div>

                </div>

                <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                            <label>CIUDAD *</label>
                                  <input class="form-control" readonly="readonly" name="ciudad" type="text" value="La Tebaida">
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label>DIRECCIÓN *</label>
                                  <input class="form-control" readonly="readonly" name="direccion" type="text" value="Cra 8 N° 6-05 Monterrey ">
                        </div>
                    </div>

                </div>


                       <div class="row">

                      <div class="col-md-4">
                        <div class="form-group">
                            <label>PORCENTAJE DE COMISIÓN POR VENTA *</label>
                              <input class="form-control" readonly="readonly" name="porcentaje_venta" type="text" value="30">
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="form-group">
                            <label>PORCENTAJE DE COMISIÓN POR COBRO *</label>
                                  <input class="form-control" readonly="readonly" name="porcentaje_cobro" type="text" value="0">
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="form-group">
                            <label>PORCENTAJE DE COMISIÓN POR EXTRA *</label>
                                  <input class="form-control" readonly="readonly" name="porcentaje_extra" type="text" value="30">
                        </div>
                    </div>

                </div>


                <div class="row">
                     <div class="col-md-6">
                        <div class="form-group">
                            <label>FECHA COMOSIÓN EXTRA *</label>
                                  <input class="form-control" readonly="readonly" name="fecha_extra" type="text" value="2022-08-06">
                        </div>
                    </div>
                </div>




            <div class="form-group">



            </div><br><br>


                <div class="clearfix"></div>
             </form>
        </div>
    </div>
</div>
