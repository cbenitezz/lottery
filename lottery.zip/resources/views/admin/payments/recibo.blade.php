<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta name="color-scheme" content="light dark">
    </head>
    <style>
        pre {
        display: block;
        font-family: monospace;
        white-space: pre;
        }
        html {
            margin: 0px;
            padding: 0px;
            font-family: 'arial';
            font-size:10px;
            text-align: left;
        }

    </style>

<body>
    <div>
        <pre>

               Sede:{{$sede}}
                Nit:{{$nit}}
                {{$fecha}}
        -----------------------------
           CAJERO:   {{$cajero}}
           RECIBO:   {{$recibo}}
        -----------------------------
            DATOS DEL VENDEDOR

        CÉDULA:   {{$cedula}}
        NOMBRE:   {{$nombreVendedor}}

        ------------------------------
        LOTERIA:  {{$loteria}}
        ------------------------------
        ABONO TOTAL:$ {{$abono}}
        ------------------------------

        </pre>


    </div>

</body>
</html>
