@extends('layouts.admin')
@section('title', 'TutziCMS - Asignar Rol')

@section('content')


<h1>editar</h1>
@endsection