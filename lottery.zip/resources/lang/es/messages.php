<?php
return [
    "add_category" => "Agregar categoría",
    "categories" => "Categorías",
    "name" => "Nombre",
    "description" => "Descripción",
    "category_created" => "Categoría creada",
    "save" => "Guardar",
    "go_back" => "Volver",
    "edit" => "Editar",
    "delete" => "Eliminar",
    "edit_category" => "Editar categoría",
    "confirm_action" => "Por favor, confirme",
    "category_updated" => "Categoría actualizada",
    "category_deleted" => "Categoría eliminada",
    "E-Mail Address"  => "Correo electrónico",
    'Email' => "Correo electrónico",
    'password' =>"Digite su contraseña",
    'Remember Me' => "Recordarme",
    'Forgotten Password?'=>"Olvidó su contraseña?",
    'Sign in'=>"Acceder",
    'Password'=> "Contraseña",

];
