<?php $__env->startSection('title', 'Crear Vendedor'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-8">
        <?php if(Session::has('succes')): ?>
            <div class="alert alert-success alert-dismissible  fade show mb-4 mt-4" role="alert">
                <i class="icon-check"></i>
                <?php echo e(Session::get('succes')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="close">
                    <span aria-hidden="true">&times;</span>
                </button>

            </div>
        <?php endif; ?>
        <?php if(Session::has('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show mb-4 mt-4" role="alert">
                <?php echo e(Session::get('error')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="close">
                    <span aria-hidden="true">&times;</span>
                </button>

            </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-header">
                <a href="<?php echo e(route('user.index')); ?>" class="btn btn-success active btn-sm float-right">
                <i class="fa fa-align-justify"></i> Listar Usuarios</a>
                <h5 class="card-title mb-0">Crear Usuarios</h5>
                <div class="small text-muted">Registro</div>

            </div>
            <div class="card-body">
              <div class="row">

                <div class="col-lg-12">

                  <?php echo Form::open(['route' => 'user.vendedor', 'method' => 'POST']); ?>


                    <div class="form-group">
                        <?php echo Form::label('name', 'Nombre'); ?>

                        <?php echo Form::text('name', null, ['class'=> 'form-control'. ( $errors->has('name') ? ' is-invalid' : '' )
                        , 'placeholder'=>'Ingrese nombre']); ?>


                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                 <span class="invalid-feedback" role="alert">
                                     <strong><?php echo e($message); ?></strong>
                                 </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>

                    <div class="form-group">

                      <?php echo Form::email('email', null, ['class'=> 'form-control'. ( $errors->has('email') ? ' is-invalid' : '' )
                      , 'placeholder'=>'Ingrese email']); ?>


                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>

                    <div class="form-group">
                        <div class="alert alert-warning" role="alert">
                            El usuario registrado tendrá como clave "password" y deberá ser cambiado al inicio de sesión
                          </div>
                    </div>

                    <?php echo Form::submit('Registrar Usuario', ['class'=>'btn btn-primary']); ?>

                  <?php echo Form::close(); ?>

                </div>

              </div>

            </div>


        </div>



    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lottery\resources\views/admin/users/vendedor.blade.php ENDPATH**/ ?>