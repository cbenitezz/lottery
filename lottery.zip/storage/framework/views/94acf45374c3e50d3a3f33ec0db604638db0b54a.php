<?php $__env->startSection('title', 'Crear Cliente / Vendedor'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-12">
        <?php if(Session::has('succes')): ?>
            <div class="alert alert-success alert-dismissible  fade show mb-4 mt-4" role="alert">
                <i class="icon-check"></i>
                <?php echo e(Session::get('succes')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="close">
                    <span aria-hidden="true">&times;</span>
                </button>

            </div>
        <?php endif; ?>
        <?php if(Session::has('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show mb-4 mt-4" role="alert">
                <?php echo e(Session::get('error')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="close">
                    <span aria-hidden="true">&times;</span>
                </button>

            </div>
        <?php endif; ?>


    </div>

</div><!-- end view -->
<div class="row">

<div class="col-lg-12">
    <div class="card">
        <div class="card-header">

            <a href="/customer" class="btn btn-success active  float-right">
                <i class="fa fa-align-justify"></i> Listar</a>
                <h5 class="card-title mb-0">Crear Cliente</h5>
                <div class="small text-muted"></div>
        </div>
        <div class="card-body">
            <!-- Credit Card -->
            <div id="pay-invoice">
                <div class="card-body">
                    <div class="card-title">

                    </div>


                    <?php echo Form::open(['route' => 'user.cliente', 'method' => 'POST']); ?>


                        <!---->
                        <div class="row">
                            <div class="col-6">
                                <div class="form-group">
                                    <?php echo Form::label('name', 'Nombre',['required','classs'=>'control-label mb-1']); ?>

                                    <?php echo Form::text('name', null, ['required','class'=> 'form-control'. ( $errors->has('name') ? ' is-invalid' : '' )
                                    , 'placeholder'=>'...']); ?>

                                    <?php echo e(Form::hidden('rol', 'cliente')); ?>


                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-6">
                               <div class="form-group">
                                    <?php echo Form::label('apellido', 'Apellido'); ?>

                                    <?php echo Form::text('apellido', null, ['required','class'=> 'form-control'. ( $errors->has('apellido') ? ' is-invalid' : '' )
                                    , 'placeholder'=>'...']); ?>


                                    <?php $__errorArgs = ['apellido'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-6">
                                <div class="form-group">
                                <?php echo Form::label('email', 'Email'); ?>

                                <?php echo Form::email('email', null, ['class'=> 'form-control'. ( $errors->has('email') ? ' is-invalid' : '' )
                                , 'placeholder'=>'cliente@estrategiasmichu.com']); ?>


                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-group">
                                <?php echo Form::label('identification_card', 'Cédula'); ?>

                                <?php echo Form::text('identification_card', null, ['required','class'=> 'form-control'. ( $errors->has('identification_card') ? ' is-invalid' : '' )
                                , 'placeholder'=>'...']); ?>


                                    <?php $__errorArgs = ['identification_card'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">

                            <div class="col-6">
                            <div class="form-group">
                                <?php echo Form::label('direccion', 'Dirección'); ?>

                                <?php echo Form::text('direccion', null, ['required','class'=> 'form-control'. ( $errors->has('direccion') ? ' is-invalid' : '' )
                                , 'placeholder'=>'...']); ?>


                                    <?php $__errorArgs = ['direccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-group">
                                    <?php echo Form::label('barrio', 'Barrio'); ?>

                                    <?php echo Form::text('barrio', null, ['required','class'=> 'form-control'. ( $errors->has('barrio') ? ' is-invalid' : '' )
                                    , 'placeholder'=>'...']); ?>


                                        <?php $__errorArgs = ['barrio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">

                            <div class="col-6">
                            <div class="form-group">
                                <?php echo Form::label('phone', 'Teléfono Movil'); ?>

                                <?php echo Form::text('phone', null, ['required','class'=> 'form-control'. ( $errors->has('phone') ? ' is-invalid' : '' )
                                , 'placeholder'=>'...']); ?>


                                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>

                        <div>
                            <?php echo Form::submit('Registrar Cliente', ['class'=>'btn btn-lg btn-info btn-block']); ?>


                        </div>


                     <?php echo Form::close(); ?>


                </div>
            </div>

        </div>
    </div> <!-- .card -->

</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lottery\resources\views/admin/users/cliente.blade.php ENDPATH**/ ?>