<!-- start Modal Update Roles -->
<div class="modal fade" id="modal-asignar-1" tabindex="-1" role="dialog" aria-labelledby="staticModalLabel" style="display: none;" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                    <div class="modal-header"><!-- start modal header -->

                        <h5 class="modal-title" id="staticModalLabel">
                            <i class="fa fa-user-circle" aria-hidden="true"></i>
                            Asignar Boleta :</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div><!-- end modal header -->
                    <div class="modal-body"><!-- start modal body -->


                    </div><!-- end modal Body -->
                    <div class="modal-footer">

                    </div>

            </div>
    </div>
</div>
<!-- End Modal Update Roles -->
<?php /**PATH C:\xampp\htdocs\lottery\resources\views/admin/ticket/modal_asignar.blade.php ENDPATH**/ ?>