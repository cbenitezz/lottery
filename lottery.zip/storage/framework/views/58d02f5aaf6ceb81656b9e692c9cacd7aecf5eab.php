 <!-- Left Sidebar  -->
 <div class="left-sidebar">
    <!-- Sidebar scroll-->
    <div class="scroll-sidebar">
        <!-- Sidebar navigation-->
        <nav class="sidebar-nav">
            <ul id="sidebarnav">
                <li class="nav-devider"></li>
                <li class="nav-label">Home</li>
                <li> <a class="has-arrow  " href="#" aria-expanded="false"><i class="fa fa-tachometer"></i><span class="hide-menu">Dashboard <span class="label label-rouded label-primary pull-right">2</span></span></a>
                    <ul aria-expanded="false" class="collapse">

                        <li><a href="index.html">Análisis </a></li>
                        <li><a href="index1.html">Reportes </a></li>
                    </ul>
                </li>
                <li class="nav-label">Rifa</li>
                <li> <a class="has-arrow  " href="#" aria-expanded="false">
                    <i class="fa fa-random"></i><span class="hide-menu">Sorteos</span></a>
                    <ul aria-expanded="false" class="collapse">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('lottery.index')): ?>
                        <li><a href="<?php echo e(route('lottery.index')); ?>">Listado</a></li>
                        <?php endif; ?>

                        <!--<li><a href="">Asignar</a></li>-->
                       <!-- <li><a href="">Ventas</a></li>
                        <li><a href="">Sorteos</a></li>
                        <li><a href="">Abonos</a></li>-->
                        <li><a href="<?php echo e(route('payment.index')); ?>">Abonos</a></li>
                    </ul>
                </li>
                <li> <a class="has-arrow  " href="#" aria-expanded="false">
                    <i class="fa fa-user-plus"></i><span class="hide-menu">Usuarios</span></a>
                    <ul aria-expanded="false" class="collapse">
                        <li><a href="<?php echo e(route('user.index')); ?>">Sistema</a></li>
                        <li><a href="<?php echo e(route('customer.index')); ?>">Clientes</a></li>
                        <li><a href="<?php echo e(route('user.vendedores')); ?>">Vendedores</a></li>
                        <li><a href="<?php echo e(route('roles.index')); ?>">Roles</a></li>

                    </ul>
                </li>
                <li class="nav-label">Contabilidad</li>
                <li> <a class="has-arrow  " href="#" aria-expanded="false">
                    <i class="fa fa-suitcase"></i><span class="hide-menu">Informes <span class="label label-rouded label-warning pull-right">6</span></span></a>
                    <ul aria-expanded="false" class="collapse">
                        <li><a href="<?php echo e(route('lottery.index')); ?>">Cartera</a></li>
                        <li><a href="<?php echo e(route('lottery.index')); ?>">Comisiones</a></li>

                    </ul>
                </li>




            </ul>
        </nav>
        <!-- End Sidebar navigation -->
    </div>
    <!-- End Sidebar scroll-->
</div>
<!-- End Left Sidebar  -->
<?php /**PATH C:\xampp\htdocs\lottery\resources\views/layouts/dashboard/sidebar.blade.php ENDPATH**/ ?>