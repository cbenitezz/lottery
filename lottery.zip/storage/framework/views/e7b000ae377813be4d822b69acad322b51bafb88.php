</div>
<!-- End Wrapper -->
<!-- All Jquery -->
<!--
<script src=""></script>-->
<script src="<?php echo e(asset('asset/js/jquery-3.5.1.js')); ?>"></script>

<!-- Bootstrap tether Core JavaScript -->
<script src="<?php echo e(asset('asset/js/lib/bootstrap/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('asset/js/lib/bootstrap/js/bootstrap.min.js')); ?>"></script>
<!-- slimscrollbar scrollbar JavaScript -->
<script src="<?php echo e(asset('asset/js/jquery.slimscroll.js')); ?>"></script>
<!--Menu sidebar -->
<script src="<?php echo e(asset('asset/js/sidebarmenu.js')); ?>"></script>

<!--stickey kit -->
<script src="<?php echo e(asset('asset/js/lib/sticky-kit-master/dist/sticky-kit.min.js')); ?>"></script>



<!--Custom JavaScript -->
<script src="<?php echo e(asset('asset/js/custom.min.js')); ?>"></script>
<?php echo $__env->yieldPushContent('script'); ?>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\lottery\resources\views/layouts/dashboard/scripts.blade.php ENDPATH**/ ?>