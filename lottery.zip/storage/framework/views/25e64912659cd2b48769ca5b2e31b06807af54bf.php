<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta name="color-scheme" content="light dark">
    </head>
    <style>
        pre {
        display: block;
        font-family: monospace;
        white-space: pre;
        }
        html {
            margin: 0px;
            padding: 0px;
            font-family: 'arial';
            font-size:10px;
            text-align: left;
        }

    </style>

<body>
    <div>
        <pre>

               Sede:<?php echo e($sede); ?>

                Nit:<?php echo e($nit); ?>

                <?php echo e($fecha); ?>

        -----------------------------
           CAJERO:   <?php echo e($cajero); ?>

           RECIBO:   <?php echo e($recibo); ?>

        -----------------------------
            DATOS DEL VENDEDOR

        CÉDULA:   <?php echo e($cedula); ?>

        NOMBRE:   <?php echo e($nombreVendedor); ?>


        ------------------------------
        LOTERIA:  <?php echo e($loteria); ?>

        ------------------------------
        ABONO TOTAL:$ <?php echo e($abono); ?>

        ------------------------------

        </pre>


    </div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\lottery\resources\views/admin/payments/recibo.blade.php ENDPATH**/ ?>