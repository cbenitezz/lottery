<!-- footer -->
<footer class="footer text-center"> © 2022 Derechos Resevados. </a></footer>
    <!-- End footer --><?php /**PATH C:\xampp\htdocs\lottery\resources\views/layouts/dashboard/footer.blade.php ENDPATH**/ ?>