<?php $__env->startSection('title', 'Listado de Roles'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-12">
        <?php if(Session::has('succes')): ?>
            <div class="alert alert-info alert-dismissible fade show mb-4 mt-4" role="alert">
                <i class="icon-check"></i>
                <?php echo e(Session::get('succes')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="close">
                    <span aria-hidden="true">&times;</span>
                </button>

            </div>
        <?php endif; ?>
        <?php if(Session::has('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show mb-4 mt-4" role="alert">
                <?php echo e(Session::get('error')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="close">
                    <span aria-hidden="true">&times;</span>
                </button>

            </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-header">
            <a href="<?php echo e(route('roles.create')); ?>" class="btn btn-success active  float-right">
            <i class="fa fa-align-justify"></i>Crear Rol</a>

            <h5 class="card-title mb-0">Listado Roles</h5>
            <div class="small text-muted">Editar - Asignar Permisos</div>
            </div>
            <div class="card-body">
              <div class="row">

                <div class="col-lg-12  table-responsive">
                    <table class="table table-striped">
                    <thead>
                        <th class="text-center">Rol</th>
                        <th class="text-center">Servicio</th>
                        <th colspan="3" class="text-center">Acciones</th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <tr>
                                <td><h6 style="font-size: 12px;padding-left:40%"><?php echo e(Str::upper($item->name)); ?></h6></td>
                                <td class="text-center"><?php echo e($item->guard_name); ?></td>
                                <td class="text-center">
                                    <?php if($item->id == 1 or $item->id == 2 or $item->id == 3 or $item->id == 4): ?>

                                        <a class="btn btn-info btn-sm" style="color:white"   data-toggle="modal" data-target="#">
                                        <i class="fa fa-lock" aria-hidden="true"></i>&nbsp;&nbsp;&nbsp;Editar </a>
                                    <?php else: ?>

                                        <a class="btn btn-info btn-sm" style="color:white" data-toggle="modal" data-target="#modal-rol-<?php echo e($item->id); ?>"><i class="fa fa-link"></i> &nbsp;Editar </a>

                                    <?php endif; ?>
                                    <?php echo $__env->make('admin.roles.modal_edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </td>
                                <td class="text-center">
                                    <div class="dropdown">

                                        <?php if($item->id == 1 ): ?>

                                        <a class="btn btn-secondary btn-sm" disabled="disabled"  data-target="#">
                                        <i class="fa fa-lock" aria-hidden="true"></i>&nbsp;Permisos</a>

                                        <?php else: ?>

                                        <a class="btn btn-secondary active btn-sm" href="<?php echo e(route('roles.show', $item->id)); ?>"><i class="fa fa-paper-plane" aria-hidden="true"></i>&nbsp;Permisos</a>
                                        <?php endif; ?>

                                    </div>


                                </td>
                                <td class="text-center">
                                    <div class="dropdown">

                                        <?php if($item->id == 1 or $item->id == 2 or $item->id == 3 or $item->id == 4): ?>

                                        <a class="btn btn-danger btn-sm" disabled="disabled"  data-target="#">
                                        <i class="fa fa-lock" aria-hidden="true"></i>&nbsp;Eliminar</a>

                                        <?php else: ?>

                                        <a class="btn btn-danger btn-sm active" data-toggle="modal" data-target="#open-<?php echo e($item->id); ?>"><i class="fa fa-trash" aria-hidden="true"></i>&nbsp;Eliminar</a>
                                        <?php endif; ?>

                                    </div>


                                    <?php echo $__env->make('admin.roles.modal_del', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                </td>



                           </tr>


                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </tbody>
                    </table>
                    <?php echo e($roles->links()); ?>

                </div>

              </div>

            </div>


        </div>



    </div>

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<script>
    $('.modal').removeClass('fade');
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lottery\resources\views/admin/roles/index.blade.php ENDPATH**/ ?>