<!-- start Modal Update Roles -->
<div class="modal fade" id="modal-abono" tabindex="-1" role="dialog" aria-labelledby="staticModalLabel" style="display: none;" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                    <div class="modal-header"><!-- start modal header -->
                        <h5 class="modal-title" id="staticModalLabel">
                            <i class="fa fa-exclamation-circle" aria-hidden="true"></i>
                            RECEPCIÓN DE ABONO <strong id="lottery"></strong>
                        </h5>

                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>

                    </div><!-- end modal header -->
                    <div class="modal-body"><!-- start modal body -->

                        <?php echo Form::open(['id'=>'form_abonar']); ?>


                            <div class="form-group">
                                <?php echo Form::label('numero', 'Numero de Boleta'); ?>

                                <?php echo Form::text('numero', null, ['class'=> 'form-control', 'placeholder'=>'', 'disabled'=>'disabled', 'id'=>'numero']); ?>

                                <?php echo Form::hidden('id', null, ['id'=>'id']); ?>

                                <?php echo Form::hidden('lottery', null, ['id'=>'lottery']); ?>


                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            </div>
                            <div class="form-group">
                                <?php echo Form::label('abono', 'Valor Abonar'); ?>

                                <?php echo Form::number('abono', null, [ 'id'=>'abono','min' => '1000', 'max' => '90000','class'=> 'form-control', 'placeholder'=>'$', 'required'=>'require']); ?>



                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            </div>
                        <?php echo Form::submit('Registrar Abono', ['class'=>'btn btn-primary']); ?>


                        <?php echo Form::close(); ?>


                        </div>
                    </div><!-- end modal Body -->
                    <div class="modal-footer">

                    </div>

            </div>
    </div>
</div>
<!-- End Modal Update Roles -->
<?php /**PATH C:\xampp\htdocs\lottery\resources\views/admin/lottery/modal_abono.blade.php ENDPATH**/ ?>