<!-- Modal -->
<div class="modal fade" id="open-<?php echo e($item->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <form action="<?php echo e(route('roles.destroy',$item->id)); ?>" method="post">
        <?php echo e(csrf_field()); ?>

        <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Eliminar Rol</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
                Desea Eliminar el Rol "<strong><?php echo e($item->name); ?></strong>" ?
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                <button type="submit" class="btn btn-primary">Aceptar</button>
              </div>
            </div>
          </div>
  
    </form>
  </div><?php /**PATH C:\xampp\htdocs\lottery\resources\views/admin/roles/modal.blade.php ENDPATH**/ ?>