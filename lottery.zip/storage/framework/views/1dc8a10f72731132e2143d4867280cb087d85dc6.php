<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-12">
        <?php if(Session::has('succes')): ?>
            <div class="alert alert-success alert-dismissible fade show mb-4 mt-4" role="alert">

                <a href="#" class="alert-link">
                     <i class="icon-check"></i>
                     <?php echo e(Session::get('succes')); ?>

                    </a>

                <button type="button" class="close" data-dismiss="alert" aria-label="close">
                    <span aria-hidden="true">&times;</span>
                </button>

            </div>
        <?php endif; ?>
        <?php if(Session::has('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show mb-4 mt-4" role="alert">
                <?php echo e(Session::get('error')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="close">
                    <span aria-hidden="true">&times;</span>
                </button>

            </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-header">
             <?php if($title == "Usuarios del Sistema"): ?>
                 <?php
                    $uri    = 'user.create';
                    $button = "btn-success";
                 ?>
             <?php elseif($title =="Cliente"): ?>
                 <?php
                    $uri = 'user.cliente';
                    $button = "btn-info";
                 ?>
             <?php elseif($title =="Vendedor"): ?>
                 <?php
                    $uri = 'user.vendedor';
                    $button = "btn-warning";
                 ?>
             <?php endif; ?>


            <a href="<?php echo e(route($uri,[ 'title'=>$title ])); ?>" class="btn <?php echo e($button); ?>  float-right">
            <i class="fa fa-plus"></i> Adicionar</a>
            <h5 class="card-title mb-0"><i class="fa fa-user" aria-hidden="true"></i> CONTROL DE USUARIOS </h5>
            <div class="small text-muted">Asignar roles - Eliminar</div>
            </div>
            <div class="card-body">
              <div class="row">

                <div class="col-lg-12 table-responsive">
                    <table class="table table-striped">
                    <thead>
                        <th><?php echo e($title); ?></th>
                        <th>Correo Electrónico</th>
                        <th class="text-center">Roles</th>
                        <th class="text-center">Acciones</th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <tr>
                                <td><?php echo e($item->name); ?></td>
                                <td><?php echo e($item->email); ?></td>
                                <td class="text-center">
                                    <?php $rolActual = $item->getRoleNames(); ?>
                                    <?php $__currentLoopData = $rolActual; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                      <span class="badge badge-success" style="color: black"><i class="fa fa-user"></i> <?php echo e($rol); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                </td>
                                <td class="text-center">
                                    <div class="dropdown">

                                        <?php if($item->id == 1): ?>

                                        <!-- Button trigger modal -->
                                        <button type="button" class="btn-secondary btn-sm" disabled="disabled"  data-toggle="modal" data-target="#">
                                            <i class="fa fa-lock"></i> &nbsp;Roles
                                        </button>

                                        <button type="button"class="btn-secondary btn-sm" disabled="disabled"  data-target="#">
                                            <i class="fa fa-lock" aria-hidden="true"></i>&nbsp;Eliminar
                                        </button>

                                        <?php else: ?>

                                        <!-- Button trigger modal -->
                                        <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#modal-edit-<?php echo e($item->id); ?>">
                                            <i class="fa fa-user"></i> &nbsp;editar
                                        </button>

                                        <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#modal-rol-<?php echo e($item->id); ?>">
                                            <i class="fa fa-link"></i> &nbsp;Roles
                                        </button>

                                        <button type="button" class="btn btn-danger active btn-sm" data-toggle="modal" data-target="#open-<?php echo e($item->id); ?>">
                                            <i class="fa fa-trash" aria-hidden="true"></i>&nbsp;Eliminar
                                        </button>
                                        <?php endif; ?>



                                    </div>


                                    <?php echo $__env->make('admin.users.modal_rol', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <?php echo $__env->make('admin.users.modal_edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <?php echo $__env->make('admin.users.modal_del', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                </td>

                           </tr>


                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </tbody>
                    </table>
                    <br>
                    <?php echo e($users->links()); ?>

                </div>

              </div>

            </div>


        </div>



    </div>

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<script>
    $('.modal').removeClass('fade');
</script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lottery\resources\views/admin/users/index.blade.php ENDPATH**/ ?>