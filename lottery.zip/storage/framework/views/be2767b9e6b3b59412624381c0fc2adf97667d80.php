<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-12">
        <?php if(Session::has('succes')): ?>
            <div class="alert alert-success alert-dismissible fade show mb-4 mt-4" role="alert">

                <a href="#" class="alert-link">
                     <i class="icon-check"></i>
                     <?php echo e(Session::get('succes')); ?>

                    </a>

                <button type="button" class="close" data-dismiss="alert" aria-label="close">
                    <span aria-hidden="true">&times;</span>
                </button>

            </div>
        <?php endif; ?>
        <?php if(Session::has('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show mb-4 mt-4" role="alert">
                <?php echo e(Session::get('error')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="close">
                    <span aria-hidden="true">&times;</span>
                </button>

            </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-header">

            <a href="<?php echo e(route('lottery.create')); ?>" class="btn btn-success active float-right">
            <i class="fa fa-plus"></i> Crear Rifa</a>
            <h5 class="card-title mb-0"><i class="fa fa-user" aria-hidden="true"></i> CONTROL DE RIFAS </h5>
            <div class="small text-muted">Listado de Sorteos</div>
            </div>
            <div class="card-body">
              <div class="row">

                <div class="col-lg-12 table-responsive">
                    <table class="table table-striped">
                    <thead>
                        <th>#</th>
                        <th>Slogan</th>
                        <th>Nombre</th>
                        <th>Sede</th>
                        <th>Inicio</th>
                        <th>Final</th>
                        <th>Asignar</th>
                        <th>Estado</th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $lotteries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lottery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <tr>
                                <td><?php echo e($lottery->id); ?></td>
                                <td><?php echo e($lottery->eslogan); ?></td>
                                <td><?php echo e($lottery->name); ?></td>
                                <td><?php echo e($lottery->sede); ?></td>
                                <td><?php echo e($lottery->date_start); ?></td>
                                <td><?php echo e($lottery->date_end); ?></td>

                                <?php if($lottery->status): ?>
                                <td>
                                  <a href="<?php echo e(route('lottery.boleteria',['id'=> $lottery->id])); ?>" class="btn btn-warning">
                                  <i class="fa fa-check-circle-o" aria-hidden="true"></i> Asignar</a>
                                </td>
                                <td>
                                  <span class="badge badge-warning">&nbsp;&nbsp;<strong><i class="fa fa-check-circle-o" aria-hidden="true"></i>
                                     Activo</strong></span>
                                </td>

                                <?php else: ?>
                                 <td>
                                    <a href="#" class="btn btn-secondary  disabled ">
                                     Terminada</a>
                                  </td>
                                  <td>
                                    <span class="badge badge-secondary"><strong>Inactivo</strong></span>
                                  </td>

                                <?php endif; ?>




                           </tr>


                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </tbody>
                    </table>

                </div>

              </div>

            </div>


        </div>



    </div>

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<script>
    $('.modal').removeClass('fade');
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lottery\resources\views/admin/lottery/index.blade.php ENDPATH**/ ?>