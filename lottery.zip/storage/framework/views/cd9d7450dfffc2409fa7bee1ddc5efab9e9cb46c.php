<!-- start Modal Update Roles -->
<div class="modal fade" id="modal-rol-<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="staticModalLabel" style="display: none;" aria-hidden="true">
                                        <div class="modal-dialog modal-sm" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="staticModalLabel">
                                                        <i class="fa fa-user-circle" aria-hidden="true"></i>
                                                        <?php echo e($item->name); ?></h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">×</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <?php echo Form::model($item, ['route'=>['user.update',$item], 'method'=>'put' ]); ?>

                                                    <?php echo Form::hidden('title', $title); ?>

                                                    <div class="row">
                                                        <div class="col-lg-12">
                                                        <h5>Listado de Roles</h5>

                                                        <div>
                                                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="input-group mb-3">
                                                                <div class="input-group-prepend">
                                                                <div class="input-group-text">
                                                                <?php echo e(Form::checkbox('roles[]', $rol->id, null, ['class'=>''])); ?>

                                                                </div>
                                                                </div>
                                                                <input type="text" class="form-control" disabled='disabled' value="<?php echo e($rol->name); ?>" aria-label="Text input with checkbox">
                                                            </div>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </div>

                                                        </div>
                                                        </div>

                                                        <?php echo Form::submit('Asignar', ['class'=>'btn btn-primary']); ?>

                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                                                    <?php echo Form::close(); ?>

                                            </div>
                                            <div class="modal-footer">

                                            </div>
                                        </div>
                                    </div>
                                    </div>
                                    <!-- End Modal Update Roles --><?php /**PATH C:\xampp\htdocs\lottery\resources\views/admin/users/modal_rol.blade.php ENDPATH**/ ?>