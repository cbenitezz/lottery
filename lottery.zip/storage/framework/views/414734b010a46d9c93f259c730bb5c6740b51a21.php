<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-12">
        <?php if(Session::has('succes')): ?>
            <div class="alert alert-success alert-dismissible  fade show mb-4 mt-4" role="alert">
                <i class="icon-check"></i>
                <?php echo e(Session::get('succes')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="close">
                    <span aria-hidden="true">&times;</span>
                </button>

            </div>
        <?php endif; ?>
        <?php if(Session::has('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show mb-4 mt-4" role="alert">
                <?php echo e(Session::get('error')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="close">
                    <span aria-hidden="true">&times;</span>
                </button>

            </div>
        <?php endif; ?>


    </div>

</div><!-- end view -->
<div class="row">

<div class="col-lg-12">
    <div class="card">
        <div class="card-header">

            <a href="<?php echo e(route('lottery.index')); ?>" class="btn btn-success active  float-right">
                <i class="fa fa-align-justify"></i> Listar </a>
                <h5 class="card-title mb-0">FORMULARIO DE CREACIÓN DE RIFA</h5>
                <div class="small text-muted"></div>
        </div>
        <div class="card-body">
            <!-- Credit Card -->
            <div id="pay-invoice">
                <div class="card-body">
                    <div class="card-title">

                    </div>


                    <?php echo Form::open(['route' => 'lottery.store', 'method' => 'POST']); ?>



                        <div class="row">
                            <div class="col-6">
                                <div class="form-group">
                                    <?php echo Form::label('eslogan', 'Slogan',['classs'=>'control-label mb-1']); ?>

                                    <?php echo Form::text('eslogan', null, ['class'=> 'form-control'. ( $errors->has('eslogan') ? ' is-invalid' : '' )
                                    , 'placeholder'=>'...']); ?>



                                    <?php $__errorArgs = ['eslogan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-6">
                               <div class="form-group">
                                    <?php echo Form::label('nit', 'NIT'); ?>

                                    <?php echo Form::number('nit', null, ['class'=> 'form-control'. ( $errors->has('nit') ? ' is-invalid' : '' )
                                    , 'placeholder'=>'...']); ?>


                                    <?php $__errorArgs = ['nit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-6">
                                <div class="form-group">
                                <?php echo Form::label('name', 'Nombre del Sorteo'); ?>

                                <?php echo Form::text('name', null, ['class'=> 'form-control'. ( $errors->has('name') ? ' is-invalid' : '' )
                                , 'placeholder'=>'...']); ?>


                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-group">
                                <?php echo Form::label('representative', 'Nombre Representante Legal'); ?>

                                <?php echo Form::text('representative', null, ['class'=> 'form-control'. ( $errors->has('representative') ? ' is-invalid' : '' )
                                , 'placeholder'=>'...']); ?>


                                    <?php $__errorArgs = ['representative'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-6">
                                <div class="form-group">
                                    <?php echo Form::label('address', 'Dirección'); ?>

                                    <?php echo Form::text('address', null, ['class'=> 'form-control'. ( $errors->has('address') ? ' is-invalid' : '' )
                                    , 'placeholder'=>'...']); ?>


                                        <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                            </div>
                            <div class="col-6">
                                <div class="form-group">
                                    <?php echo Form::label('sede', 'Sede'); ?>

                                    <?php echo Form::select('sede', ['Calarca' => 'Calarcá', 'Montenegro' => 'Montenegro','Tebaida'=>'Tebaida'],
                                    null, ['class'=> 'form-control'. ( $errors->has('sede') ? ' is-invalid' : '' )
                                    , 'placeholder'=>'Seleccione la Sede']); ?>


                                        <?php $__errorArgs = ['sede'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                            </div>
                            <div class="col-6">
                            <div class="form-group">
                                <?php echo Form::label('date_start', 'Fecha de Inicio'); ?>

                                <?php echo Form::date('date_start', null, ['class'=> 'form-control'. ( $errors->has('date_start') ? ' is-invalid' : '' )
                                , 'placeholder'=>'...']); ?>


                                    <?php $__errorArgs = ['date_start'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-6">
                            <div class="form-group">
                                <?php echo Form::label('date_end', 'Fecha Final'); ?>

                                <?php echo Form::date('date_end', null, ['class'=> 'form-control'. ( $errors->has('date_end') ? ' is-invalid' : '' )
                                , 'placeholder'=>'...']); ?>


                                    <?php $__errorArgs = ['date_end'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-3">
                            <div class="form-group">
                                <?php echo Form::label('ticket_value', 'Valor de la Boleta'); ?>

                                <?php echo Form::text('ticket_value', null, ['class'=> 'form-control'. ( $errors->has('ticket_value') ? ' is-invalid' : '' )
                                , 'placeholder'=>'$', 'onkeypress'=>"return event.charCode >= 48 && event.charCode <= 57",'maxlength'=>"5",
                                'pattern'=>"\d{5}"]); ?>


                                    <?php $__errorArgs = ['ticket_value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-3">
                                <div class="form-group">
                                    <?php echo Form::label('commission_sale', 'Comisión por Venta'); ?>

                                    <?php echo Form::text('commission_sale', null, ['class'=> 'form-control'. ( $errors->has('commission_sale') ? ' is-invalid' : '' )
                                    , 'placeholder'=>'$', 'onkeypress'=>"return event.charCode >= 48 && event.charCode <= 57",'maxlength'=>"5",
                                     'pattern'=>"\d{5}"]); ?>


                                        <?php $__errorArgs = ['commission_sale'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            <div class="col-3">
                            <div class="form-group">
                                <?php echo Form::label('lottery', 'Loteria'); ?>

                                <?php echo Form::text('lottery', null, ['class'=> 'form-control'. ( $errors->has('lottery') ? ' is-invalid' : '' )
                                , 'placeholder'=>'...']); ?>


                                    <?php $__errorArgs = ['lottery'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-3">
                                <div class="form-group">
                                    <?php echo Form::label('boletas', 'Número de Boletas'); ?>

                                    <?php echo Form::select('boletas', ['500' => '500', '1000' => '1.000','10000'=>'10.000'],null, ['class'=> 'form-control'. ( $errors->has('boletas') ? ' is-invalid' : '' )
                                    , 'placeholder'=>'Seleccione la Cantidad']); ?>


                                        <?php $__errorArgs = ['boletas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                        </div>
                        <div>
                            <?php echo Form::submit('Registrar '.$title, ['class'=>'btn btn-lg btn-info btn-block']); ?>


                        </div>


                     <?php echo Form::close(); ?>


                </div>
            </div>

        </div>
    </div> <!-- .card -->

</div>
</div><!-- End -->


<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>


<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lottery\resources\views/admin/lottery/create.blade.php ENDPATH**/ ?>