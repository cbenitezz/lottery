<?php $__env->startSection('content'); ?>


<!-- Start Page Content -->
<div class="row">
    <div class="col-md-3">
        <div class="card bg-primary p-20">
            <div class="media widget-ten">
                <div class="media-left meida media-middle">
                    <span><i class="ti-bag f-s-40"></i></span>
                </div>
                <div class="media-body media-text-right">
                    <h2 class="color-white">Activos:<?php echo e($lotteryActive); ?>

                        <span class="label label-rouded label-warning "><?php echo e($lotteries); ?></span>
                    </h2>
                    <p class="m-b-0">Número de Sorteos</p>

                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-pink p-20">
            <div class="media widget-ten">
                <div class="media-left meida media-middle">
                    <span><i class="ti-user f-s-40"></i></span>
                </div>
                <div class="media-body media-text-right">
                    <h2 class="color-white"><?php echo e($customer); ?></h2>

                    <p class="m-b-0">Número de Clientes</p>

                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-success p-20">
            <div class="media widget-ten">
                <div class="media-left meida media-middle">
                    <span><i class="ti-user f-s-40"></i></span>
                </div>
                <div class="media-body media-text-right">
                    <h2 class="color-white"><?php echo e($seller); ?></h2>

                    <p class="m-b-0">Número de Vendedores</p>

                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-danger p-20">
            <div class="media widget-ten">
                <div class="media-left meida media-middle">
                    <span><i class="ti-money f-s-40"></i></span>
                </div>
                <div class="media-body media-text-right">
                    <h2 class="color-white"><?php echo e(number_format($paidTicketTotal)); ?></h2>

                    <p class="m-b-0">Total Recaudado</p>

                </div>
            </div>
        </div>
    </div>
</div>



<div class="row">

    <div class="col-lg-4">
        <div class="card">
            <div class="card-title">

                <h4>Boletas Asignadas por Sorteo</h4>

            </div>
            <div class="card-body">
                <div class="current-progress">

                        <?php $__currentLoopData = $lotteriesTicket; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lottery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php
                        $tickectsAsignados = 0;
                        ?>

                        <div class="progress-content">
                        <div class="row">
                            <div class="col-lg-4">
                                <div class="progress-text"><?php echo e(substr($lottery->name, 0, 7)); ?>

                                    <span class="label label-rouded label-primary pull-right"><?php echo e($lottery->id); ?></span>
                                </div>
                            </div>
                            <div class="col-lg-8">
                                <div class="current-progressbar">
                                    <div class="progress">
                                        <?php
                                            $totalTickects=count($lottery->tickets);
                                            $porcentaje = 0;
                                        ?>

                                        <?php $__currentLoopData = $lottery->tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($ticket->status==1): ?>
                                                <?php
                                                $tickectsAsignados +=1;
                                                ?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                           $porcentaje = ($tickectsAsignados*100)/$totalTickects;
                                           $porcentaje = round($porcentaje,0);
                                        ?>

                                        <div class="progress-bar progress-bar-primary w-<?php echo e($porcentaje); ?>" role="progressbar" aria-valuenow="<?php echo e($porcentaje); ?>" aria-valuemin="0" aria-valuemax="100">
                                            <?php echo e($porcentaje); ?>%
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div><!-- row -->
                        </div>


                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




                </div>
            </div>
        </div>
    </div>
    <!-- /# column -->
    <div class="col-lg-4">

    <div class="card">
            <div class="card-title">
                <h4>Recaudo por Sorteo</h4>
            </div>
            <div class="card-body">
                <div class="current-progress">

                    <?php $__currentLoopData = $lotteriesTicket; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lottery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <?php
                    $tickectsAcumulado = 0;
                    ?>

                    <div class="progress-content">
                    <div class="row">
                        <div class="col-lg-4">
                            <div class="progress-text"><?php echo e(substr($lottery->name, 0, 7)); ?>

                                <span class="label label-rouded label-warning pull-right"><?php echo e($lottery->id); ?></span>
                            </div>
                        </div>
                        <div class="col-lg-8">
                            <div class="current-progressbar">
                                <div class="progress">
                                    <?php
                                        $totalTickects=900000000;
                                        $porcentaje = 0;
                                    ?>

                                    <?php $__currentLoopData = $lottery->tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($ticket->paid_ticket>0): ?>
                                            <?php
                                            $tickectsAcumulado = $tickectsAcumulado + $ticket->paid_ticket;
                                            ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                       $porcentaje = ($tickectsAcumulado*100)/$totalTickects;
                                       $porcentaje = round($porcentaje,0);
                                    ?>

                                    <div class="progress-bar progress-bar-warning w-<?php echo e($porcentaje); ?>" role="progressbar" aria-valuenow="<?php echo e($porcentaje); ?>" aria-valuemin="0" aria-valuemax="100" style="color: black">
                                        $ <?php echo e(number_format($tickectsAcumulado)); ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><!-- row -->
                    </div>


                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




                </div><!-- end current-progress -->

            </div>
        </div>
    </div>
    <div class="col-lg-4">

    <div class="card">
            <div class="card-title">
                <h4>Top Vendedores</h4>

            </div>
            <div class="card-body">
                <div class="current-progress">
                    <?php
                       $top =0;
                    ?>
                    <?php $__currentLoopData = $bestSellers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                      <?php if($top == 6): ?>
                      <?php break; ?>
                      <?php endif; ?>

                    <div class="progress-content">
                    <div class="row">
                        <div class="col-lg-8">
                            <div class="progress-text"><?php echo e(substr($key, 0, 15)); ?>


                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="current-progressbar">
                                <div class="progress">
                                    <?php
                                        $top +=1;
                                        $porcentaje = 0;
                                    ?>



                                    <div class="progress-bar progress-bar-warning w-<?php echo e($porcentaje); ?>" role="progressbar" aria-valuenow="<?php echo e($porcentaje); ?>" aria-valuemin="0" aria-valuemax="100" style="color: black">
                                        $ <?php echo e(number_format($value,2,'.',',')); ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><!-- row -->
                    </div>


                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




                </div><!-- end current-progress -->
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startPush('style'); ?>



<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lottery\resources\views/layouts/dashboard/index.blade.php ENDPATH**/ ?>