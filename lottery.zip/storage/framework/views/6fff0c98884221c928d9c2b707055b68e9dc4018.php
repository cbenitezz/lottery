<?php $__env->startSection('title', 'Crear Cliente / Vendedor'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-12">
        <?php if(Session::has('succes')): ?>
            <div class="alert alert-success alert-dismissible  fade show mb-4 mt-4" role="alert">
                <i class="icon-check"></i>
                <?php echo e(Session::get('succes')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="close">
                    <span aria-hidden="true">&times;</span>
                </button>

            </div>
        <?php endif; ?>
        <?php if(Session::has('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show mb-4 mt-4" role="alert">
                <?php echo e(Session::get('error')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="close">
                    <span aria-hidden="true">&times;</span>
                </button>

            </div>
        <?php endif; ?>


    </div>

</div><!-- end view -->
<div class="row">

<div class="col-lg-12">
    <div class="card">
        <div class="card-header">

            <a href="/customer" class="btn btn-success active  float-right">
                <i class="fa fa-align-justify"></i> Listar</a>
                <h6 class="card-title mb-0"><strong>Cliente :<?php echo e($customer->name); ?></strong></h6>
                <div class="small text-muted">Debe Seleccionar Sorteo y Números</div>
        </div>
        <div class="card-body">
            <!-- Credit Card -->
            <div id="pay-invoice">
                <div class="card-body">
                    <div class="card-title">

                    </div>

                    <form  id="form_select_ticket">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" id="customer" name="customer" value="<?php echo e($customer->id); ?>">
                        <div class="row">
                                <div class="col-4">
                                    <div class="form-group">
                                        <label class="control-label">Seleccione el Sorteo</label>
                                        <select class="form-control" id="lottery_id" name="lottery_id">

                                            <?php $__currentLoopData = $lotteries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>">
                                            <?php echo e(strtoupper($value)); ?>

                                            </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                </div>
                                <div class="col-4">
                                    <div class="form-group">
                                        <label class="control-label">Digite Número</label>
                                        <input type="text" maxlength="4" pattern="\d{4}|\d{3}" required id="tickets"
                                         onkeypress="return event.charCode >= 48 && event.charCode <= 57"
                                         class="form-control" placeholder="#" id="tickets" name="tickets">

                                        <small id="messages" class=" hidden form-control-feedback color-danger">
                                        <strong> Boleta no Válida </strong></small>



                                            <small id="messages" class=" hidden form-control-feedback color-danger">
                                            <strong> Boleta no Válida </strong></small>
                                            <?php $__errorArgs = ['ticket'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-4">
                                    <div class="form-group" >
                                        <label class="control-label">Abono Total</label>
                                        <input type="text" id="abono" name="abono" maxlength="5" pattern="\d{4}|\d{5}"
                                        onkeypress="return event.charCode >= 48 && event.charCode <= 57" required
                                        class="form-control form-control-danger"  placeholder="$"  min ="1000" max ="90000">
                                        <small id="messages_pay" class="form-control-feedback color-dark">
                                        Valor minimo $5000</small>
                                    </div>
                                </div>
                        </div>
                        <!---->


                        <div class="row">
                            <div class="col-md-4">
                                <button type="submit" id="registro_ticket" class="btn btn-lg btn-info btn-block" >
                                    <span class="color-white">Registrar Números</span>
                                </button>
                            </div>
                            <div class="col-md-4">
                                <button type="submit" id="registro_save_ticket" class="btn btn-lg btn-success btn-block" >
                                    <span class="color-white">Guardar Cliente y Números</span>
                                </button>
                            </div>

                            </div>
                        </div>

                    </form>
                   <br>
                </div>
            </div>
            <div class="card-footer">
                Numeros Registrados:<span id="numbersregister"></span>
              </div>
        </div>

    </div> <!-- .card -->

</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<script>
    $('.modal').removeClass('fade');
    $("#user_seller_cc").hide();
    $("#registro_save_ticket").hide();

    $('#form_select_ticket').submit(e=>{
            e.preventDefault();

            let customer   = $('#customer').val();
            let lottery_id = $('#lottery_id').val();
            let tickets    = $('#tickets').val();
            let abono      = $('#abono').val();

            $.ajaxSetup({
                headers: {
                  'X-CSRF-TOKEN': $('input[name="_token"]').attr('value')
                }
            });

            //alert(lottery_id + "   " +tickets + "   " +customer +"   " + abono );
            $.ajax({
                    type: "POST",
                    url: '/admin/users/customer',
                    data:{
                        lottery_id:lottery_id,
                        tickets   :tickets,
                        customer  :customer,
                        abono     :abono,

                    },
                    success: function (result){
                        $("#registro_save_ticket").show();
                        if(result.data == 'invalida')
                        {
                            $("#messages").show();

                        }
                        if(result.data == true){
                           console.log(result.ticket);
                           $('#tickets').val('');
                           $('#numbersregister').append('<strong>'+result.ticket +'-'+'</strong>');
                        }
                        if(result.data == 'pagada')
                        {
                          $("#messages_pay").show();
                          $("#messages_pay").fadeOut(2000);

                        }


                    },
                    error: function (result) {
                        console.log('Error:', result);
                    }
                });

        });

      /* -------------------CLICK BUTTOM------------------- */


      $("#registro_save_ticket").click(function () {

       let tickets = [];
       let numbers = $('#numbersregister').text();

       alert(numbers);
       event.preventDefault();
/*
        $.ajaxSetup({
                headers: {
                  'X-CSRF-TOKEN': $('input[name="_token"]').attr('value')
                }
            });
            $.ajax({
                    type: "POST",
                    url: '/printer',
                    data:{
                        array_table,
                        usuario_seller,
                        lottery,
                        usuario_cajero,
                        usuario_seller_cc,
                    },
                    success: function (result){
                        console.log(result);

                        if(result.data == true){

                           // imprimir();
                        //window.location.href = '/storage/'+result.filePdf;
                         window.open('/storage/'+result.filePdf, '_blank');
                        //console.log(result.contar);
                        }

                    },
                    error: function (result) {
                        console.log('Error:', result);
                    }
                });

*/

   });


</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lottery\resources\views/admin/users/cliente-paso2.blade.php ENDPATH**/ ?>