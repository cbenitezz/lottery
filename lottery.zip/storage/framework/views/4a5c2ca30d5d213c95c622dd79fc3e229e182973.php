<!-- start Modal Update Roles -->
<div class="modal fade" id="modal-edit-<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="staticModalLabel" style="display: none;" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                    <div class="modal-header"><!-- start modal header -->

                        <h5 class="modal-title" id="staticModalLabel">
                            <i class="fa fa-user-circle" aria-hidden="true"></i>
                            Editar :<?php echo e($item->profile->name); ?> | <?php echo e($item->profile->identification_card); ?></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div><!-- end modal header -->
                    <div class="modal-body"><!-- start modal body -->

                        <?php echo Form::model($item->profile, ['route'=>['customer.update',$item->profile->id], 'method'=>'put' ]); ?>

                        <div class="row">
                            <div  class="col-lg-6"><!-- Col1 -->
                                <?php echo Form::hidden('title', $item->getRoleNames()); ?>

                                <?php echo Form::hidden('id', $item->profile->id); ?>


                                <div class="form-group">

                                        <?php echo Form::label('name', 'Nombre', ['style'=>"float:left; margin-left:10px"]); ?>

                                        <?php echo Form::text('name', null, ['class'=> 'form-control'. ( $errors->has('name') ? ' is-invalid' : '' )
                                        , 'placeholder'=>'...','required'=>'required', 'maxlength'=>80]); ?>


                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group">

                                        <?php echo Form::label('sede', 'Sede', ['style'=>"float:left; margin-left:10px"]); ?>

                                        <?php echo Form::select('sede', ['Calarca' => 'Calarcá', 'Montenegro' => 'Montenegro','Tebaida'=>'Tebaida'],
                                         'Tebaida', ['class'=> 'form-control'. ( $errors->has('sede') ? ' is-invalid' : '' )]); ?>


                                        <?php $__errorArgs = ['sede'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                </div>
                                <div class="form-group">
                                        <?php echo Form::label('sector', 'Barrio', ['style'=>"float:left; margin-left:10px"]); ?>

                                        <?php echo Form::text('sector', null, ['class'=> 'form-control'. ( $errors->has('sector') ? ' is-invalid' : '' )
                                        , 'placeholder'=>'...','required'=>'required', 'maxlength'=>50]); ?>


                                        <?php $__errorArgs = ['sector'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div  class="col-lg-6"><!-- Col2 -->


                                <div class="form-group">

                                        <?php echo Form::label('last_name', 'Apellido', ['style'=>"float:left; margin-left:10px"]); ?>

                                        <?php echo Form::text('last_name', null, ['class'=> 'form-control'. ( $errors->has('last_name') ? ' is-invalid' : '' )
                                        , 'placeholder'=>'...','required'=>'required', 'maxlength'=>80]); ?>




                                        <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                </div>
                                <div class="form-group">

                                        <?php echo Form::label('address', 'Dirección', ['style'=>"float:left; margin-left:10px"]); ?>

                                        <?php echo Form::text('address', null, ['class'=> 'form-control'. ( $errors->has('address') ? ' is-invalid' : '' )
                                        , 'placeholder'=>'...','required'=>'required', 'maxlength'=>80]); ?>


                                        <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                </div>
                                <div class="form-group">

                                        <?php echo Form::label('phone', 'Teléfono Movil', ['style'=>"float:left; margin-left:10px"]); ?>

                                        <?php echo Form::number('phone', null, ['class'=> 'form-control'. ( $errors->has('phone') ? ' is-invalid' : '' )
                                        , 'placeholder'=>'...','required'=>'required', 'maxlength'=>15]); ?>


                                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                </div>
                            </div>
                            <div  class="col-lg-6">
                                <div class="form-group">
                                 <?php echo Form::submit('Actualizar', ['class'=>'btn btn-primary']); ?>

                                 <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                                </div>
                            </div>

                        <?php echo Form::close(); ?>

                        </div>
                    </div><!-- end modal Body -->
                    <div class="modal-footer">

                    </div>

            </div>
    </div>
</div>
<!-- End Modal Update Roles -->
<?php /**PATH C:\xampp\htdocs\lottery\resources\views/admin/users/modal_edit.blade.php ENDPATH**/ ?>