<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CustomerRecords extends Model
{
    protected $table = 'customers_records';
}
