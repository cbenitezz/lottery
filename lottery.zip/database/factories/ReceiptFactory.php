<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Receipt;
use Faker\Generator as Faker;

$factory->define(Receipt::class, function (Faker $faker) {
    return [
        //
    ];
});
